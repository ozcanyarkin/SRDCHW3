package com.SRDCHW2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Srdchw2Application {

	public static void main(String[] args) {
		SpringApplication.run(Srdchw2Application.class, args);
	}

}
